
let isLightTheme = true;
let startingTime;
let endingTime;
let changeThemeButton;
let displayButton;
let loadBtn;
let bodyTitle;
let allButtons;
let allTextStyleEle;
let errorMsgs;
let timeFormatErrMsg;
let dropdownErrMsg;
let timeOrderErrMsg;
let successMsgEle;
let hoursInterval;
let minutesInterval;

document.addEventListener( "DOMContentLoaded", () => {
  changeThemeButton = document.getElementById('changeThemeButton');
  displayButton = document.getElementById( "dispBtn" );
  loadBtn = document.getElementById( "loadBtn" );
  bodyTitle = document.getElementById( "bodyTitle" );
  startingTime = document.getElementById('starttime');
  endingTime = document.getElementById('endtime');
  timeFormatErrMsg = document.getElementById( "timeFormatErr" );
  dropdownErrMsg = document.getElementById( "dropdownErr" );
  timeOrderErrMsg = document.getElementById( "timeOrderErr" );
  successMsgEle = document.getElementById( "successMsg" );
  createIntervals();
  defaultStyles();
 
} );

function createIntervals() {
  hoursInterval = math.range( 0, 24, 1, false )._data;
  minutesInterval = math.range( 0, 60, 15, false )._data;
}

function defaultStyles() {
  displayButton.disabled = true;
  allButtons = [ ...document.getElementsByTagName( "button" ) ];
  allTextStyleEle = [ ...document.getElementsByClassName( "text-dark" ) ];
  errorMsgs = [ ...document.getElementsByClassName( "errorMsg" ) ];
  errorMsgs.map( msg => { msg.style.color = "red"; msg.style.display = 'none'; } );
  successMsgEle.style.display = "none";
}

function changeTheme() {
  var element = document.body;
  element.classList.toggle("dark");
}

function loadClick() {
  let timeFormat = document.querySelector( 'input[name="timeformat"]:checked' );
  if ( timeFormat == null ) {
    timeFormatErrMsg.style.display = 'block';
  } else {
    timeFormatErrMsg.style.display = 'none';
    loadDropDowns( timeFormat.value );
  }
}

function loadDropDowns( timeFormat ) {
  let timeData = Array.from( {
    length: 24 * 60 / 15
  }, ( val, index ) => {
    let h = Math.floor( index * 15 / 60 );
    let m = minutesInterval[ index % 4 ];
    if ( m < 10 ) {
      m = '0' + m;
    }
    let label = '';
    if ( timeFormat == "12hours" ) {
      label = 'AM';
      if ( h > 11 ) {
        label = 'PM';
      }
      if ( h > 12 ) {
        h -= 12;
      }
    }

    if ( h < 10 ) {
      h = '0' + h;
    }

    if ( label.length > 0 ) {
      return h + ':' + m + ' ' + label;
    } else {
      return h + ':' + m;
    }

  } );
  loadDataIntoDropDowns( timeData );
}

function loadDataIntoDropDowns( timeData ) {
  let starttimeEle = document.getElementById( "starttime" );
  let endtimeEle = document.getElementById( "endtime" );
  resetDropdowns( starttimeEle, endtimeEle );
  timeData.forEach( element => {
    var option = document.createElement( "option" );
    option.text = element;
    option.value = element;
    starttimeEle.appendChild( option );

    option = document.createElement( "option" );
    option.text = element;
    option.value = element;
    endtimeEle.appendChild( option );
  } );
  displayButton.disabled = false;
}

function resetDropdowns( startTimeEle, endTimeEle ) {
  startTimeEle.innerHTML = "";
  endTimeEle.innerHTML = "";
  var option = document.createElement( "option" );
  option.text = "Please Select";
  option.value = "0";
  option.selected = true;
  startTimeEle.appendChild( option );

  option = document.createElement( "option" );
  option.text = "Please Select";
  option.value = "0";
  option.selected = true;
  endTimeEle.appendChild( option );
}

function displayBtnClick() {
 // let startTimeEle = document.getElementById( "starttime" );
  let startTime = startingTime.value;
  //let endTimeEle = document.getElementById( "endtime" );
  let endTime = endingTime.value;
  let successMsg = "";

  if ( startTime == '0' || endTime == '0' ) {
    dropdownErrMsg.style.display = 'block';
  } else {
    dropdownErrMsg.style.display = 'none';
    console.log(startTime);
    startTimeHours = startTime.substring( 0, 5 ).split( ":" ).map( num => Number( num ) );
    endTimeHours = endTime.substring( 0, 5 ).split( ":" ).map( num => Number( num ) );
    console.log(startTimeHours);
    startPeriod = startTime.slice( -2 );
    console.log(startPeriod);
    endPeriod = endTime.slice( -2 );

    successMsg = getSuccessMsg( startTimeHours[ 0 ], startTimeHours[ 1 ], endTimeHours[ 0 ], endTimeHours[ 1 ], startPeriod, endPeriod );

    if ( startPeriod == "PM" ) {
      startTimeHours[ 0 ] += 12;
    }
    if ( endPeriod == "PM" ) {
      endTimeHours[ 0 ] += 12;
    }

    let d1 = new Date( 2001, 8, 1, startTimeHours[ 0 ], startTimeHours[ 1 ] );
    let d2 = new Date( 2001, 8, 1, endTimeHours[ 0 ], endTimeHours[ 1 ] );
    if ( d1 > d2 ) {
      timeOrderErrMsg.style.display = 'block';
      successMsgEle.style.display = "none";
    } else {
      timeOrderErrMsg.style.display = 'none';
      successMsgEle.style.display = "block";
      successMsgEle.innerText = successMsg;
    }
  }
}

function getSuccessMsg( sh, sm, eh, em, sampm, eampm ) {
  if ( sampm == "AM" || sampm == "PM" ) {
    return "You selected start time as " + sh + " Hours and " + sm + " minutes " + sampm + " and you selected end time as " + eh + " Hours and " + em + " minutes " + eampm;
  } else {
    return "You selected start time as " + sh + " Hours and " + sm + " minutes and you selected end time as " + eh + " Hours and " + em + " minutes";
  }
}

function clearData() {
  var ele = document.getElementsByName( "timeformat" );
  for ( var i = 0; i < ele.length; i++ ) {
    ele[ i ].checked = false;
  }

  let starttimeEle = document.getElementById( "starttime" );
  let endtimeEle = document.getElementById( "endtime" );
  resetDropdowns( starttimeEle, endtimeEle );

  errorMsgs.map( msg => msg.style.display = 'none' );
}



