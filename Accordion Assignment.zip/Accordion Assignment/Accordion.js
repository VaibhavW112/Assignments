let contentbox = document.getElementsByClassName('contentbox');

for(let i=0; i<contentbox.length;i++)
{
    contentbox[i].addEventListener('click',function() {
       this.classList.toggle('active')
    })
}